This folder work exactly as modules folder, however is intended to place only mods here.
