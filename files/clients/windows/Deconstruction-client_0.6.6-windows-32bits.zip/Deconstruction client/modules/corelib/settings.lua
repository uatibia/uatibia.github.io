g_settings = makesingleton(g_configs.getSettings())

-- Reserved for future functionality
